/*
 * Motores.c
 *
 * Created: 28/01/2022 12:36:45 a. m.
 * Author : JOHAN
 */ 

#include <avr/io.h>
#include "Motores.h"
#define F_CPU	16000000
#include <util/delay.h>

int main(void)
{
	DDRD = 0x0f;
	DDRC = (1<<5);
	PORTD = 0x00;
	char a=0;
    /* Replace with your application code */
    while (1) 
    {
		a = (dir & 0xf0);
		switch (a)
		{
		case (1<<4):
		TLeft();
		break;
		case (1<<5):
		TBackwards();
		break;
		case (1<<6):
		TTowards();
		break;
		case (1<<7):
		TRight();
		break;
		case 0:
		stop();
		break;
	}
    }
}

